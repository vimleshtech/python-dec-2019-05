s = input('enter string value :')


print('you have entered ',s)

#upper
print(s.upper())

#lower
print(s.lower())

#title
print(s.title())

#captilize
print(s.capitalize())

#strip
print(s.strip())
print(s.lstrip())
print(s.rstrip())

#len

print(len(s))

##
print(s.replace('a','xy'))




#count
print(s.count('a'))


#

print(list(s))

##
print(s.split(' '))

















      
