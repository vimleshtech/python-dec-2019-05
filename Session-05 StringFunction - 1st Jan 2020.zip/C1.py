s = input('enter string :')

print(s.count(' '))
print(s.count('\t'))
print(s.count('\n'))


####
print(s.swapcase())

##or
o = list(s)
for c in o:
    if c.isupper():
        print(c.lower())
    else:
        print(c.upper())
        
              
    


