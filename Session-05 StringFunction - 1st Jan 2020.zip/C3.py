##C3
s = input('enter string value :')

#this is test code
print( len(s) - s.count(' '))

w = s.split(' ')
print(len(w))


####C5
v = ['a','e','i','o','u']
d = ['0','1','2','3','4','5','6','7','8','9']

w = list(s)
vc= 0
cc =0
dc =0
sc = 0
for c in w:
    c = c.lower()
    
    if c in v:
        vc=vc+1        
    elif ord(c)>=48 and ord(c) <=57:#c in d:
        dc = dc+1
    elif ord(c)>=97 and ord(c)<=123:
        cc=cc+1
    else:
        sc =sc+1





        
        
        



print(vc)
print(cc)
print(dc)




        
        
