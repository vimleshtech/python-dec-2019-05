d = []

for i in range(10):
    a = int(input('enter data :'))
    d.append(a)



n = int(input('enter index to rotate :'))

print(d)

x = d[:n] #copy data from 0 to given index
d[:n]=[] #remove the data from original list

print(x)
print(d)

#merge
for m in x:
    d.append(m)

print(d)

      

