d = []

for i in range(10):
    a = int(input('enter data :'))
    d.append(a)


pc =0
nc = 0
oc = 0
ec = 0
for x in d:
    if x<0:
        nc=nc+1
    else:
        pc=pc+1
        
    if x % 2 ==0:
        ec=ec+1
    else:
        oc=oc+1

print('neg count :',nc)
print('pos count :',pc)
print('odd count :',oc)
print('even count :',ec)








        
        
        
    
