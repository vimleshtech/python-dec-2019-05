sales = [111,23,445,55,3333]

print('highest value',max(sales))
print('lowest value ',min(sales))
print('total ',sum(sales))
print('count ',len(sales))


sales.sort()
print(sales)

print(sales[0:3]) #from 0
print(sales[:3]) #from 0

#in desc
print(sales[::-1])


sales.append(3345)
sales.append(13345)
print(sales)

sales.pop()
print(sales)


sales.insert(2,2000)
print(sales)


if 2 in sales:
    sales.remove(2)
    print(sales)






