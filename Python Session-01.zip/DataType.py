a =11
b =544.5
c ='test 34334'
d ="hello..44"
e = True

f =[111,33,55,56]
t= (111,333,5,566)
di ={1:'one','a':'alpha'}

s = {11,333,55,111}

print('int', type(a))
print('float' ,type(b))
print('str', type(c))
print('str' ,type(d))
print('bool ',type(e))
print('list ',type(f))
print('tuple ',type(t))
print('dict ',type(di))
print('set ',type(s))


#declartion of variable
a =111
a1 =111
#1a =444 #error

a,b = 11,22
print(a)
print(b)

x=y=100
print(x)
print(y)
y = 200
print(x)
print(y)



a= [11,22,44]
b = a
print(a)
print(b)
a[0]= 100 #will also change the value of b
print(a)
print(b)

##
a =10
b =a
print(a)
print(b)
a =11    #b will not be change 
print(a)
print(b)

#wap to swap the value
n1 =10
n2 =33

n1,n2=n2,n1
print(n1)
print(n2)
























