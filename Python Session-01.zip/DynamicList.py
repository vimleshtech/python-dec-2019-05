
data = [] #empty list

hs = input('enter data ')
es = input('enter data ')
cs = input('enter data ')
ms = input('enter data ')
ss = input('enter data ')


data.append(hs)
data.append(es)
data.append(cs)
data.append(ms)
data.append(ss)

print(data)

