
#WAP to get sum of two numbers
n1 =444
n2           =   9545

#expression
n =n1+n2

#show/print
print('sum of two numebrs ',n)

