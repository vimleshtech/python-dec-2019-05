a =44
b =555
c =a+b
print(c)

