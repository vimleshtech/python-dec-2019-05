import pandas as pd

a = pd.DataFrame() #data frame is table
print(a)

#create dataframe from dict and list

emp = {
    'eid':[1,2,3,4,5],
    'name':['nitin','divya','nitisha','jyoti','monika'],
    'gender':['male','female','femlae','female','female'],
    'salary':[11111,22222,33333,44444,55555]}

print(emp)

#convert to data frame
o = pd.DataFrame(data=emp)
print(o)

print(o.columns)
print(o.index)

#read particular column
print(o['name'])
print(o[['name','salary']])
print(o[['name','salary','gender']])


#show data type
print(o.info())

##shape
print(o.shape)

#show top 2 rows
print(o.head(n=2))

#show from buttom
print(o.tail(n=2))


###rename the column
o.columns=['ecode','ename','gender','sal']

print(o)


























