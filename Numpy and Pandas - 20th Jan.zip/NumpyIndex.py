import numpy as np

a =[1,2,3,4,5,6,7,8,9]

x = np.array(a).reshape(-1,3)

print(x)

#read from 1st row to end , and all columns
print(x[1:,])

print(x[0:2,1:2])

