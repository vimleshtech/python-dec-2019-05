import numpy as np

#array 
x = np.arange(10)
print(x)

x = np.arange(4,10,.2)
print(x)

print(x*2)

#List
a =[11,33,566,7]
print(a)
print(a*2)


###
x = np.ones(1000)
print(x)

x = np.zeros(1000)
print(x)


##convert list to array
a = [1,2,3,4,5,6,7,8,9]
a = np.array(a)
print(a)

###shape
print(a.shape)

#reshape
y =a.reshape(-1,3)
print(y)
print(y.shape)


z =y*2
print(z)
#set data type
a = [1,2,3,4,5,6,7,8,9]
m = np.array(a,dtype=int)
print(m)


####methods
print(np.add(y,z))
print(np.subtract(y,z))
print(np.multiply(y,z))
print(np.divide(y,z))
print(np.multiply(y,z))


###















