##read data from .csv file or excel file


import pandas as pd
data = pd.read_csv(r'C:\Users\ANUJ RAJPUT\Desktop\emp.csv')

print(data)

