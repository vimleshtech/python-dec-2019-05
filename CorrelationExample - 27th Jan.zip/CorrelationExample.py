import pandas as pd

student_data = {'sid':[1,2,3,5,10] ,
                'sname':['Nitin','Jaitn','Divya','Ayush','Monika'],
                'hours':[6,9,5,12,7],
                'marks':[55,87,50,96,82]}


#convert/create dataframe
student = pd.DataFrame(data=student_data)

print(student)

##corr: works for numeric column
print(student.info())

print(student.describe())

print(student.corr())
