import pandas as pd
import matplotlib.pyplot as plt

#read and write from and with file
data = pd.read_csv(r'C:\Users\vkumar15\Desktop\Learning & Training\emp.csv')
print(type(data))
print(data.shape)
print(data)

##get column names
print(data.columns)


#read particular coumn
print(data['name'])


#get name and salary
print(data[['name','salary']])
      

#
sal = data['salary'] #read salary form dataframe
print(type(sal))

#print(sal*12)
ysal = [] #empty list
for s in sal:
    #print(s*12)
    ysal.append(s*12)

print(ysal)

#add new column in existing dataframe
data['yal'] = ysal

print(data)
print(sum(ysal))


#store data to csv
#data.to_csv(r'C:\Users\vkumar15\Desktop\Learning & Training\new_emp.csv')
#print('data is saved')

    
#data.plot() #default type is line chart
data.plot(kind='bar') #default type is line chart
plt.show()
















