import numpy as np

#there are following inbuilt methods of numpy
x= np.arange(10) #generate the sequence from 0 to 9
print(x)

#generate the sequece from given number to end number and with given incrementer
x= np.arange(4,10,.2) #from 4 4.2 4.4 ....  9.8
print(x)


##differnece between list and array
a = [11,3,4,5,6] #list
print(type(a))
print(a*2) #double the size of list

##array: convert list to array
x = np.array(a)
print(type(x))
print(np.array(a)*2) #multiple every number by 2


##shape : return dimenssion of array
x= np.arange(9)
print(x)
print(x.shape)

#reshpe
y = x.reshape(-1,1) # -1, 1 column
print(y)
print(y.shape)

y = x.reshape(-1,3) # -1, 3 columns
print(y)
print(y.shape)

###data type , default data type for number is float
a =[100,323.5,4,5.3,643.5,333.3]
x = np.array(a,dtype=float)
print(x)

##array operation
print(x)
print(x*.18) 
print(x*1.18)  #118 %

#### multi dimenssion array

a =  y 
b =  y *2
print(a)
print(b)
print(type(a))
print(type(b))

print(a.shape)
print(b.shape)

### add, substruct, multiply, divide
print(np.add(a,b))
print(np.subtract(a,b))
print(np.multiply(a,b))
print(np.divide(a,b))

'''
a=
[
[0  15 2]
[10 14 2]
[20 1 2]
]

a[row index , col index ]
a[1:3, 1]
'''

print(a[1:3, 1])
print(a[0:2, 1:3])





















         














