sid = input('enter sid:')
name = input('enter sid:')

hs = input('enter mark in hindi:')
es = input('enter mark in eng:')
cs =input('enter mark in comp:')
ms  = input('enter mark in math :')

print(type(sid))
print(type(name))
print(type(es))
print(type(cs))
print(type(ms))
print(type(hs))


total = int(hs) + int(es) + int(cs) + int(ms) #int() to convert str to int
avg  = total/4
print('eid is ',sid)
print('name is ',name)
print('total score is ',total)
print('average  is ',avg)


