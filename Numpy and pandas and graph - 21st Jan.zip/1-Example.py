a = 11
b =454
c =a*b

print(c)
