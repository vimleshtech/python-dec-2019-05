import os

#res = os.listdir() #from current directory

os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training')
res = os.listdir(r'C:\Users\vkumar15\Desktop\Learning & Training')

print(os.getcwd()) #print current directory



#print(res)
#read all data from  all .txt files
for file in res:
    if file.endswith(".txt"):
        #print(file)
        data= open(file,'r') #error
        print(data.read()) 
        
        
    
