'''
module: os (os is module or library)
'''
import os

#res = os.listdir() #from current directory
res = os.listdir(r'C:\Users\vkumar15\Desktop\Learning & Training')


print(res)
#get file and folder count
print(len(res))

#get .txt fle count
fc = 0
pdfc=0
for file in res:
    if file.endswith(".txt"):
        fc=fc+1
    if file.endswith(".pdf"):
        pdfc=pdfc+1

print('count of file is',fc)

        






