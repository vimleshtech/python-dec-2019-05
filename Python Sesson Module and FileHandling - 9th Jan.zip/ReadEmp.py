f = open(r'C:\Users\vkumar15\Desktop\Learning & Training\employee.txt')
#print(f.read())
f.readline()

d = f.readlines()

print(d)
c = 0
f = 0

#total salary
total=0
for row in d:
    #print(row)
    col = row.split(',')
    #print(col)
    if col[2] =='male':
        c =c+1
    elif col[2]=='female':
        f=f+1

    total = total + int(col[3]) 
    

print(c)
print(f)
print(total)

    
    
