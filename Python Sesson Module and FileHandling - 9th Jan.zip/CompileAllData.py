#read data from all .txt file and write on master file
import os 

#change directory 
os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training')

#get list of files and folder
res = os.listdir()

#create new file in write mode 
w= open('master.txt','w')

#read all file and folder one by one 
for file in res:
    if file.endswith(".txt"):  #if text file
        data= open(file,'r') #open the file and read the content
        w.write(data.read()) #write the content to another file

w.close() #save the master file 
print('all data has saved to master.txt file')

        
        
    

