

a = int(input('enter num :'))
b = int(input('enter num :'))
    

try:
    
    f = open(r'C:\Users\vkumar15\Desktop\Java.txt')
    #print(f.read())

    if b<0:
        ex = ZeroDivisionError('divisor cannot be less than 0')
        raise ex
    c =a/ b
    print(c)
except NameError as e:
    print(e)
except ZeroDivisionError as er:
    print(er)
except:
    #pass
    print('there is technical error, plz change your data !!!')
finally:
    print('end of block ')
    f.close()
    
    
#
c =a+b
print(c)

    
    






