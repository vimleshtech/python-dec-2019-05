#no argument no return
def wel():
    print('welcome to function world !!!')
    print('this code contains following function : well(), add(), sub(), mul()')


#no argument with return
def getResult():
    a = int(input('enter data :'))
    b = int(input('enter data :'))
    return a,b

#argument with return
def add(a,b):
    c=a+b
    return c
    
#argument with no return
def fact(n):
    x = 1
    while n>0:
        x = x*n
        n =n-1
    print(x)
    
#call to function
wel()

x,y = getResult()
print(x+y)


x,y = getResult()
print(x-y)


out = add(11,333)
print(out)
    
    
out = add(1551,3323)
print(out)


fact(5)

