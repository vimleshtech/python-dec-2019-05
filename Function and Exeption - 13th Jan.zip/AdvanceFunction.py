#argument with default value
def add(a,b=0,c=0,d=0,e=0):
    m =a+b+c+d+e
    print(m)

#argument with dynamic count of input 
def mul(*arg): #* syntax
    print(arg) #arg type is tuple
    s = 0
    for x in arg:
        s=s+x

    print(s)
    
#recussion : function which call or invokes itself
def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1)  # 5 * fact(4 )*  fact(3 ) * fact(2)
    

##lambda : single line function or one line expression
tax = lambda amt: amt*.18
'''
def tax(amt):
   amt = amt*.18
   return amt
'''
    

add(11)
add(11,4545)

add(11,4545,4)
add(11,4545,4,5)
add(11,4545,44,5,6)

mul(11,33,45,6,34)
mul(11,33,45,6,333,4,5,634)

f = fact(6)
print(f)

t = tax(1333)
print(t)
