#continue example
for i in range(1,10):
    if i%3==0:  #is number divisable by 3
        continue  #skip the current iteration 
    
    print(i)
    
