data = [] #declare empty list

for i in range(5):
    d = input('enter data :')
    data.append(d)



print(data)


##print data from list one by one
for x in data:
    print(x)

#or
for i in range(0,len(data)):
    print(data[i])
    
    
