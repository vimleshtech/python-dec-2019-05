sales = [11,13,5,5656,33,5666,33,5,5,4,34,5,5,5,6,7,5]

print('max ',max(sales))
print('min ',min(sales))
print('sum ',sum(sales))
print('len ',len(sales))

##sort
sales.sort()
print(sales)
#slicer
print(sales[0]) #return first value
print(sales[-1]) #return last value , negative index read data from right to left

print(sales[0:4]) #fron 0 to 3 index
print(sales[:4]) #fron 0 to 3 index

print(sales[::])  #from 0 to last 
print(sales)  #from 0 to last

print(sales[::2]) #from 0 to len on 2 gap
print(sales[::-1]) #print in reverse


##add new value at last
sales.append(100)
sales.append(110)
print(sales)


##pop : remove last value
print(sales.pop())
print(sales.pop())
print(sales.pop())
print(sales)

##insert : add new value at given position
sales.insert(2,567)
print(sales)

#remove
sales.remove(33)
print(sales)

sales.remove(sales[0])
sales.remove(sales[4])
print(sales)


###exmaple : remove all 5 from list
for i in range(0,len(sales)):
    if 5 in sales:
        sales.remove(5)

print(sales)







          












