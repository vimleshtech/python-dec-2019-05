#2d list

#2 * 
a = [[111,33,45,56],[555,433,556]]

print(a)

for r in a:  # [[]] => []
    #print(r) 
    for c in r:#[] = data
        print(c,end='\t')
    print()
        
    

