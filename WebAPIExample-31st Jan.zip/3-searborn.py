# Import the libraries
import matplotlib.pyplot as plt
import seaborn as sns 
import pandas as pd

data ={'eid':[1,2,3,4,5,6,7,8,9,10],
       'name':['ayush','jatin','divya','mohit','monika','nitisha','raman','gaurav','kshitiz','nidhi'],
       'gender':['male','male','female','male','female','female','male','male','male','female'],
       'age':[21,22,23,41,25,36,47,38,49,41],
       'salary':[10000,20000,30000,40000,50000,60000,70000,80000,90000,100000]
       }

titanic = pd.DataFrame(data=data)

print('plz wait..')


# Set up a factorplot
g = sns.factorplot("name", "salary", "age", data=titanic, kind="bar", size=6, palette="muted", legend=True)

# Set the `yscale`
g.set(yscale="log")

# Show plot
plt.show()


    
