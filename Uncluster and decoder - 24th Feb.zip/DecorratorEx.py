
def x(func): #func will receive the name of caller function 

    print(func)
    func()
        


@x
def y():
    print('in y func ')


y()

    
    
    
