def wel():
    print('welcome to fun world ....!!!!')
    print('we are learning function .... in python !!!')


def getNum():
    a = int(input('enter data :'))
    
    b = int(input('enter data :'))
    return a,b

def add(a,b,c):
    m =a+b+c
    print(m)

def sub(a,b):
    c =a-b
    return c

#call or invoke to function
wel()

x,y = getNum()
print(x+y)

x,y = getNum()
print(x-y)


add(22,44,55)
add(22,44,54)

o = sub(55,6)
print(o)
add(22,44,o)



