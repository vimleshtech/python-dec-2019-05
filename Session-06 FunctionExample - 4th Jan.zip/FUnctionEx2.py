def add(a,b=0,c=0):
    m =a+b+c
    print(m) 

def mul(*a):
    print(a)
    print(type(a))

    x= 1
    for d in a:
        x*=d
    print(x)


def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1)


#lambda
tax = lambda x: x*1.18

add(30)
add(30,55)
add(30,55,566)


mul(4445,66,677,4444,66)
mul(4445,66,677,4444,66,54,5656,66)

print(fact(5))


print(tax(1200))


