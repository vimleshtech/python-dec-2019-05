s = input('enter str :')

##c9
f = input('enter str :')

if s.count(f)>0:
   print('given ... value is found ')
#

#c5
c = list(s)

print(c)
dc = 0
sc = 0
vc=0
cc=0

for w in c:
    
    #print(ord(w.lower()))
    if w.isdigit() : #ord(w.lower()) >=48 and ord(w.lower())<=57:
          dc+=1
    elif ord(w.lower()) >=97 and ord(w.lower())<=123:
        if w in ['a','e','i','o','u']:
            vc +=1
        else:
            cc+=1
            
    else:
        sc+=1
        

    ##
    #if w.lower() == f.lower():
    #    print(w.swapcase())
        

print(dc)

print(vc)

print(cc)

print(sc)
