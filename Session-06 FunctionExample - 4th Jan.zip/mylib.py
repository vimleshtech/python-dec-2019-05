def wel():
    print('welcome to fun world ....!!!!')
    print('we are learning function .... in python !!!')


def getNum():
    a = int(input('enter data :'))
    
    b = int(input('enter data :'))
    return a,b

def add(a,b,c):
    m =a+b+c
    print(m)

def sub(a,b):
    c =a-b
    return c

