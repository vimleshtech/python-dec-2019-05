Function and module
==========================
Function : is set is command or statement which is reusable
Advantages:
        - Reusability of source code
        - Support to modular programing, large/complex code can be written in small set
        - Easy to manage the source

Syntax:
        def func_name():
                    ..
                    ...

There are following types of functions:
    i. no argument no return
        def wel():
                    ...
                    ..
    ii. no argument with return
        def getNum():
            ....
            ...
            return data
        
    iii. argument with no return
        def add(a,b):
                ...
                ....
                
    iv. argument with return
        def sub(a,b):
                ..
                ..
                return data 
    v. function with argument and default(optional) value
        def mul(a,b,c=1):
            ..
            ...
        mul(1,3)
        mul(4,55,6)
    vi. function with dynamic arguments
        def mul(*a): #type of argument is tuple 

            ...
        mul(11,444,5)
        mul(54,66,433,56,43,5666,5)
    vii. recussive function: function which call/invoke itself
        def fact(n):
            if n ==1:
                    ...return ..
            else:
                return n*fact(n-1)
    
    viii. lambda expression / anonyms function
            a = lambda x: x*2
            or
            def a(x):
                x =c*2
                return x
            a(2)

    
module:  is library (user defined, system defined)
       : is container of classes, and function s


    
    

