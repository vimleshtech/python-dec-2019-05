import mylib

mylib.wel()


#or
import mylib as a
a.wel()


##or
from mylib import *
wel()
add(44,5,4)

#or
from mylib import add,wel
wel()
