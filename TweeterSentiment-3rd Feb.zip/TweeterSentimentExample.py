import tweepy
from textblob import TextBlob
import re

ck="Jm6WDXZuiwlwUnT9mFbPdSpcg"
cs="Wp4Gbf74R6MZWjXvj0ifKrCobwWbchhn53Mv8L7VMLbIUi6Wnd"
at="919434545924935681-wFjVVTbs0pmyB2VwSoj4VwGb7tBYCyr"
ats ="RaPfxU0rSMjkS3MSI9N0ztXu4I2iLMecXg79OerNHw4Ly"

res = tweepy.OAuthHandler(ck,cs)
res.set_access_token(at, ats)


api = tweepy.API(res)
print(api,'login success')


#clean tweet 
def clean_tweet(tweet):
    return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ", tweet).split())

#get polarity
def get_sentiment(tweet):
    analysis = TextBlob(tweet)

    if analysis.sentiment.polarity>0:
        return 'positive'
    elif analysis.sentiment.polarity==0:
        return 'neutral'
    else:
        return 'negative'

#fetch tweet
def get_tweet(l,c=10):
    tw = api.search(q=l,count=c)
    print(tw)
    print(len(tw))

    tweet_out=[]
    for t in tw:
        try:
            #print(clean_tweet(t.text))
            ct =clean_tweet(t.text)
            tweet_out.append(get_sentiment(ct))
        except:
            #print(clean_tweet(t.text.encode()))
            ct = clean_tweet(t.text.encode())
            get_sentiment(ct)
            tweet_out.append(get_sentiment(ct))

    #print(tweet_out)
    return tweet_out

    

########WAP to fetch the tweet for given leader

for i in range(1):
    leader = input('enter leader name :')
    out = get_tweet(leader)

    pos = [o for o in out if o=='positive']
    neg = [o for o in out if o=='negative']
    neu = [o for o in out if o=='neutral']

    c = len(out)
    print('pos ', (len(pos) / c)*100)
    print( 'neg ',(len(neg)/c)*100)
    print('neu ', (len(neu)/c)*100)
    
    


    
    


    
    



    
    
    













