#while loop
#print series from 1 to 10
i =1
while i<=10:
    print(i)
    i=i+1

    
#print in one row/line
i =1
while i<=10:
    print(i,end='') #don/t change row
    i=i+1
    

#print in reverse order
i =10
while i>0:
    print(i)
    i=i-1
    
    
#wap to print table of given numbers
t = int(input('enter num :'))
i =1
while i<=10:
    #print(t*i)
    print('{} * {} = {}'.format(t,i,t*i))
    i=i+1
    
#wap to get sum of all even and odd numbers between two given input
a = int(input('enter data :'))
b = int(input('enter data :'))
se =0 #sum of even
so =0 #sum of odd


while a<=b:

    if a%2 ==0:
        se =se+a
    else:
        so =so+a
    a=a+1

print('sum of all even numbers :',se)
print('sum of all odd numbers :',so)
















