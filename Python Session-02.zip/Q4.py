
n = int(input('enter num :'))

n = n**3 # n pow 3
print(n)



