hs = int(input('ener mark in hidndi :'))
es = int(input('ener mark in eng :'))
cs = int(input('ener mark in comp :'))
ms = int(input('ener mark in math :'))
ss = int(input('ener mark in social :'))

total = hs+es+cs+ms+ss
avg = total/5

if avg>=60:
    print('Frist')
elif avg>=50:
    print('Second')
elif avg>=40:
    print('Third')
else:
    print('Fail')
    
