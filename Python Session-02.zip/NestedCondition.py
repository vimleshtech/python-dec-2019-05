#nested if else condition 
#wap to get three input from user and show the greater number using nested condition & and operator

a = int(input('enter data :'))
b = int(input('enter data :'))
c = int(input('enter data :'))

#parent condition 
if a>b:
    #nested condition 
    if a>c:
        print('a is greater ')
    else:
        print('c is greater')
else:
    if b>c:
        print('b is greater')
    else:
        print('c is greater')


#or using and opearator

if a>b and a>c:  #if both condition true then output is true 
    print('a is greater')
elif b>a and b>c:
    print('b is greater')
else:
    print('c is greater')

    


    

    




        


