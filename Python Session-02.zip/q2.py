Name = input('enter data ')
RollNo = input('enter data ')
Subject1 = int(input("Marks of subject1 "))
Subject2 = int(input("Marks of subject2 "))
Subject3 = int(input("Marks of subject3 "))
Subject4 = int(input("Marks of subject4 "))
Subject5 = int(input("Marks of subject5 "))


Sum = (Subject1+Subject2+Subject3+Subject4+Subject5)
Avg = (Subject1+Subject2+Subject3+Subject4+Subject5)/5

print(Name)
print(RollNo)
print(Sum)
print(Avg)
