l = int(input('enter num :'))
b = int(input('enter num :'))

o = l*b*3.14

print(o)


