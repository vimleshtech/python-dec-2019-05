a = int(input('enter data :'))
b = int(input('enter data :'))

s =0

while a<=b:
    
    if a%2 ==0 and a%5 != 0  and a%3==0: # != is not equal
        s=s+a
    a=a+1

print(s)

