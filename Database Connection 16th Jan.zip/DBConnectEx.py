import mysql.connector as c

#establish the connection 
con = c.connect(host='localhost',user='root',password='root',database='python_db')

#create object to execute sql command
cmd = con.cursor()

def get_data():
    cmd.execute('select * from users')

    #fetch data
    data = cmd.fetchall()

    #print(data)
    for row in data:
        #print(row)
        print(row[0],row[1])
        
def write_data():
    i = input('enter uid :')
    n = input('enter name :')
    s = input('enter sal :')
    
    #cmd.execute("insert into users(uid,name,salary) values(100,'chahat',18000)")
    cmd.execute("insert into users(uid,name,salary) values({},'{}',{})".format(i,n,s))
    con.commit() #save data
    print('data is saved')
    


#call to function
write_data()
get_data()


    
    





