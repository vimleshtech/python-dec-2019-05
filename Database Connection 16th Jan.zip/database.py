import mysql.connector as c

connection = c.connect(host='localhost',user='root',password='root',database='blackberry_db')

var=connection.cursor()


var.execute('select * from users')

data= var.fetchall()

i = input('enter uid:')
n = input('enter name:')
s = input('enter salary:')

var.execute("insert into users(uid,name,salary) values({},'{}',{})".format(i,n,s))
connection.commit()
print('data is saved')
